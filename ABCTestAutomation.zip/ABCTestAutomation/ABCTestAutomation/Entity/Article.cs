﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.Entity
{
  public  class Article
    {
        IWebElement element;

        public Article(IWebElement element)
        {
            this.element = element;
        }

        public string getTitleArticle()
        {
            return element.FindElement(By.CssSelector("h3 a")).Text;

        }

        public string getTimestampArticle()
        {
            return element.FindElement(By.CssSelector(".published .timestamp")).Text;

        }
        public string getTextArticle()
        {
            return element.FindElement(By.CssSelector(".published ~ p:not(.topics)")).Text;

        }
    }
}

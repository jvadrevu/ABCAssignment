﻿using ABCTestAutomation.PageObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.Tests
{
    [TestClass]
   public class SocialMediaTests : BaseTest
    {
        public SocialMediaTests()
        {
            string url = ConfigurationManager.AppSettings["abcSocialMediaURL"].ToString();
            driver.Navigate().GoToUrl(url);
        }

        #region 5)	Verify that a video loads and appears successfully on the following page
        [TestMethod]
        [TestCategory("abcFacebook")]
        public void Validate_Facebook_launch()
        {
            RadioPage radioPage = new RadioPage(driver);
            Assert.IsTrue(radioPage.ClickAndVerifyShareFaceBook(), "Failed to load facebook window");
            radioPage.CloseWindow();
        }

        #endregion

        #region 5)	Verify that a video loads and appears successfully on the following page
        [TestMethod]
        [TestCategory("abcTwitter")]
        public void Validate_Twitter_launch()
        {
            RadioPage radioPage = new RadioPage(driver);
            Assert.IsTrue(radioPage.ClickAndVerifyShareTwitter(), "Failed to load Twitter window");
            radioPage.CloseWindow();
        }

        #endregion


        #region 5) Verify that when you click on ‘Download audio’ you are directed to the mp3 file (will play in browser unless right click and select Download)
        [TestMethod]
        [TestCategory("DownloadAudio")]
        public void Validate_Download_Audio()
        {
            RadioPage radioPage = new RadioPage(driver);
            Assert.IsTrue(radioPage.ClickandVerifyDownloadAudio(), "Failed to download audio");
        }
        #endregion

        #region 6)	Verify that when you click on ‘Listen now’ (from previous url) you are re-directed to the following url:
        //        https://radio.abc.net.au/programitem/pg1aGbWlx6?play=true 

        [TestMethod]
        [TestCategory("ListernAudio")]
        public void Validate_Listern_Audio()
        {
            RadioPage radioPage = new RadioPage(driver);
            Assert.IsTrue(radioPage.ClickandVerifyListenAudio(), "Failed to open Listern audio");
            radioPage.CloseWindow();
            
        }

        #endregion
    }
}
﻿using ABCTestAutomation.PageObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.Tests
{
    [TestClass]
    public class VideoTests : BaseTest
    {
        public VideoTests()
        {
            string url = ConfigurationManager.AppSettings["abcVideoURL"].ToString();
            driver.Navigate().GoToUrl(url);
        }

        #region 5)	Verify that a video loads and appears successfully on the following page
        [TestMethod]
        [TestCategory("abcVideo")]
        public void Validate_If_Video_Is_Loaded_And_Appears()
        {
            VideoPage videoPage = new VideoPage(driver);
            Assert.IsTrue(videoPage.IsVideoLoaded(), "Failed to load video");
        }

        #endregion
    }
}

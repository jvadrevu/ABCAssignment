﻿using ABCTestAutomation.Entity;
using ABCTestAutomation.PageObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.Tests
{
    [TestClass]
    public class AbcNewsTests : BaseTest
    {
        NewsPage newsPage;

        public AbcNewsTests()
        {
            string url = ConfigurationManager.AppSettings["abcNewsURL"].ToString();
            driver.Navigate().GoToUrl(url);
            newsPage = new NewsPage(driver);
        }

        #region 1) Verify that the page loads successful.

        [TestMethod]
        [TestCategory("abcNews")]
        public void Validate_If_News_Page_Is_Loaded()
        {
           // NewsPage newsPage = new NewsPage(driver);
            Assert.IsTrue(newsPage.AssertPage(), "Failed to load news page");
        }

        #endregion

        #region	2) Verify that News banner loads

        [TestMethod]
        [TestCategory("abcNews")]
        public void Validate_If_News_Banner_Is_Loaded()
        {
           // NewsPage newsPage = new NewsPage(driver);
            Assert.IsTrue(newsPage.VerifyBannerLoaded(), "Failed to load Banner");
        }

        #endregion

        #region	3) Verify can navigate to the ‘Just In’ page via the link on the primary navigation.

        [TestMethod]
        [TestCategory("abcNews")]
        public void Verify_If_I_Can_Navigate_To_JustIn_Page()
        {
           // NewsPage newsPage = new NewsPage(driver);
            newsPage.ClickMenu("Just In");

            JustinPage justInPage = new PageObjects.JustinPage(driver);
            Assert.IsTrue(justInPage.AssertPage(), "Failed to load Justin page");

        }

        #endregion

        #region 4) Verify that on the ‘Just In’ page (http://www.abc.net.au/news/justin/)  that the content per article loads correctly, i.e. must contain Title, Timestamp, Text
        [TestMethod]
        [TestCategory("abcNews")]
        public void Verify_Title_Timestamp_Text_In_Article_JustInPage()
        {
           // NewsPage newsPage = new NewsPage(driver);
            newsPage.ClickMenu("Just In");

            JustinPage justInPage = new PageObjects.JustinPage(driver);
            foreach (var articleSelected in justInPage.GetArticlesList())
            {
                Article article = new Article(articleSelected);
                Assert.IsTrue(article.getTitleArticle().Length > 0 ? true : false, "Failed to find Title in Article");
                Assert.IsTrue(article.getTimestampArticle().Length > 0 ? true : false, "Failed to find Timestamp in Article");
                Assert.IsTrue(article.getTextArticle().Length > 0 ? true : false, "Failed to find Text in Article");
            }
        }
        #endregion


    }
}

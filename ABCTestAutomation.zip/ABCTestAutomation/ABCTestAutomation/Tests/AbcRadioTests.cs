﻿using ABCTestAutomation.PageObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.Tests
{
    [TestClass]
    public class AbcRadioTests : BaseTest
    {

        RadioPage radioPage;

        public AbcRadioTests()
        {
            
            string url = ConfigurationManager.AppSettings["abcRadioURL"].ToString();
            driver.Navigate().GoToUrl(url);
             radioPage = new RadioPage(driver);
        }

        #region 1)	Verify can navigate to a ‘Program’ (e.g. ‘Big Ideas’) from the Programs sub-menu.

        [TestMethod]
        [TestCategory("abcRadio")]
        public void Verify_Navigate_Program_Sub_Menu()
        {
           // RadioPage radioPage = new RadioPage(driver);
            Assert.IsTrue(radioPage.AssertPage(), "Failed to load abc radio page");
            radioPage.ClickMenu("Programs", "Big Ideas");
            Assert.AreEqual(radioPage.GetProgramPageTitle(), "Big Ideas - ABC Radio National (Australian Broadcasting Corporation)", "Failed to load");
        }

        #endregion

        #region 3)	Verify can search for content in the search bar and that content is returned.

        [TestMethod]
        [TestCategory("abcRadio")]
        public void Verify_Serach_Bar()
        {
            //RadioPage radioPage = new RadioPage(driver);
            Assert.IsTrue(radioPage.AssertPage(), "Failed to load abc radio page");
            radioPage.SetSearchText("test");
            radioPage.ClickSearch();

            SearchPage searchPage = new SearchPage(driver);
            Assert.IsTrue(searchPage.AssertPage(), "Failed to load search page");
            Assert.IsTrue(searchPage.IsSeachcontentAvailable(), "Failed to load content" + searchPage.GetSearchRecordCountMessage());
        }

        #endregion

        #region 3)	Verify can search for content in the search bar and that content is returned.

        [TestMethod]
        [TestCategory("abcRadio")]
        public void Verify_Navigate_LastProgram()
        {
            //RadioPage radioPage = new RadioPage(driver);
            string lastProgram = radioPage.GetLastProgram();
            radioPage.ClickLastProgram();
            Assert.IsTrue(radioPage.AssertProgramPage(lastProgram), "Failed to navigate to Last Program" + lastProgram);

        }

        #endregion


    }
}

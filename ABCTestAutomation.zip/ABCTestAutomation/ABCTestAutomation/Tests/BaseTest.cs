﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.Tests
{
    public abstract class BaseTest
    {
        protected static IWebDriver driver;

        static BaseTest()
        {
            try
            {
                driver = new ChromeDriver();
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
                driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                driver.Manage().Window.Maximize();
                AppDomain.CurrentDomain.DomainUnload += CurrentDomain_DomainUnload;
            }
            catch(Exception e)
            {
                throw e;
            }
        }

        static void CurrentDomain_DomainUnload(object sender, EventArgs e)
        {
            driver.Quit();
        }

        [TestInitialize]
        public void TestInit()
        {
            driver.Manage().Cookies.DeleteAllCookies();
        }
    }
}

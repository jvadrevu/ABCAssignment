﻿using ABCTestAutomation.PageObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.Tests
{
    [TestClass]
    public class PicOfTheWeekTests : BaseTest
    {

        PicOfTheWeekPage picOfTheWeekPage;

        public PicOfTheWeekTests()
        {
            string url = ConfigurationManager.AppSettings["abcImageURL"].ToString();
            driver.Navigate().GoToUrl(url);
            picOfTheWeekPage = new PicOfTheWeekPage(driver);
        }

        #region 6)	Verify that the Current,Previous & next Images are successfully loads and images appear correctly.
        [TestMethod]
        [TestCategory("abcPic")]
        public void Validate_If_Image_Is_Loaded_And_Appears()
        {
            //PicOfTheWeekPage picOfTheWeekPage = new PicOfTheWeekPage(driver);
            Assert.IsTrue(picOfTheWeekPage.AssertPage(), "Failed to load pic of the week page");
            Assert.IsTrue(picOfTheWeekPage.IsImageGalleryLoaded(), "Failed to load image gallery");
            Assert.IsTrue(picOfTheWeekPage.IsImgLoaded(), "Failed to load pic of the week");
            Assert.IsTrue(picOfTheWeekPage.IsImgCaptionLoaded(), "Failed to load image caption");
            Assert.IsTrue(picOfTheWeekPage.IsPicAvailable(), "Failed to load pic of the week page");
        }
       
        [TestMethod]
        [TestCategory("abcPic")]
        public void Validate_If_NextImage_Is_Loaded_And_Appears()
        {
            picOfTheWeekPage.ClickNext();
            Validate_If_Image_Is_Loaded_And_Appears();
            picOfTheWeekPage.ClickPrev();
            Validate_If_Image_Is_Loaded_And_Appears();
        } 
        #endregion
    }
}

﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ABCTestAutomation.PageObjects
{
    public class ABCNewsBasePage
    {
       public IWebDriver driver;
        public ABCNewsBasePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        //Scenario 3 To navigate to Justin page
        public void ClickMenu(string menuText)
        {
            List<IWebElement> menuItemsList = driver.FindElements(By.CssSelector("#primary-nav li a")).ToList();
            foreach(IWebElement menuElement in menuItemsList)
            {
                if(menuElement.Text.Trim().Equals(menuText.Trim()))
                {
                    menuElement.Click();
                    break;
                }
            }
        }

                //         Scenario 2 -Verify that News banner loads:
        public bool VerifyBannerLoaded()
        {
             return new WebDriverWait(driver, TimeSpan.FromSeconds(5)).Until(a => a.FindElement(By.CssSelector("#header .brand")).Displayed) ;
        }

    }
}

﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ABCTestAutomation.PageObjects
{
    public class VideoPage : ABCNewsBasePage, IAssertPage
    {
        public VideoPage(IWebDriver driver) : base(driver)
        {

        }

        public bool AssertPage()
        {
            return new WebDriverWait(driver, TimeSpan.FromSeconds(5)).Until(ExpectedConditions.TitleContains("Just In - ABC News (Australian Broadcasting Corporation)"));
        }



        //Scenario 5 : Verify that the vedio  loads successful.

        public bool IsVideoLoaded()
        {

            bool isLoaded = false;

            new WebDriverWait(driver, TimeSpan.FromSeconds(30)).Until(ExpectedConditions.ElementIsVisible(By.CssSelector(".jwplayer .jwdisplayIcon")));
            driver.FindElement(By.CssSelector(".jwplayer .jwdisplayIcon")).Click();

            string videoTimeStamp = null;
            int wait = 0;
            do
            {
                Thread.Sleep(5000);
                videoTimeStamp = driver.FindElement(By.CssSelector(".jwplayer .jwcontrolbar .jwtext")).GetAttribute("textContent");
                wait++;

            } while (videoTimeStamp.Equals("00.00") && wait < 30);


            if (!videoTimeStamp.Equals("00:00"))
            {
                isLoaded = true;
            }

            return isLoaded;
        }


    }
}

﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.PageObjects
{
    public class JustinPage : ABCNewsBasePage, IAssertPage
    {

        public JustinPage(IWebDriver driver)
            : base(driver)
        {

        }

        public bool AssertPage()
        {
            return new WebDriverWait(driver, TimeSpan.FromSeconds(5)).Until(ExpectedConditions.TitleContains("Just In - ABC News (Australian Broadcasting Corporation)"));
        }

        public List<IWebElement> GetArticlesList()
        {
            return driver.FindElements(By.CssSelector("ul.article-index li")).ToList();
        }
    }
}

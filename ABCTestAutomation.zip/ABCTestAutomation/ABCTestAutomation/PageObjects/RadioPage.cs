﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.PageObjects
{
    public class RadioPage : ABCRadioBasePage, IAssertPage
    {
        public RadioPage(IWebDriver driver) : base(driver)
        {

        }

        public bool AssertPage()
        {
            return new WebDriverWait(driver, TimeSpan.FromSeconds(5)).Until(ExpectedConditions.TitleContains("ABC Radio National (Australian Broadcasting Corporation)"));
        }

        public bool AssertProgramPage(string selectedProgram)
        {
            return new WebDriverWait(driver, TimeSpan.FromSeconds(5)).Until(ExpectedConditions.TitleContains(selectedProgram));
        }

        public string GetProgramPageTitle()
        {
            return driver.Title;
        }

        public string GetLastProgram()
        {
            IList<IWebElement> programList = driver.FindElements(By.CssSelector(".at-a-glance li:not(.guide) a .program")).ToList();
            int programListCount = programList.Count;
            return programList[programListCount - 1].GetAttribute("textContent").ToString();
        }


        public void ClickLastProgram()
        {
            do
            {
                driver.FindElement(By.CssSelector("#right-arrow")).Click();
            } while (!driver.FindElements(By.CssSelector(".at-a-glance li.guide")).ToList()[1].Displayed);

            IList<IWebElement> programList = driver.FindElements(By.CssSelector(".at-a-glance li:not(.guide) a")).ToList();
            int programListCount = programList.Count;
            driver.FindElements(By.CssSelector(".at-a-glance li:not(.guide) a"))[programListCount - 1].SendKeys(Keys.Enter);
        }


        public bool ClickAndVerifyShareFaceBook()
        {

            IWebElement elementFacebook = driver.FindElement(By.CssSelector(".fb-share-button")).FindElement(By.XPath("//span/iframe"));
            IWebDriver iframeDriver = driver.SwitchTo().Frame(elementFacebook);

            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", iframeDriver.FindElement(By.CssSelector("#facebook button")));
            iframeDriver.FindElement(By.CssSelector("#facebook button")).Click();
            IWebDriver facebookWindow = driver.SwitchTo().Window(driver.WindowHandles[1]);
            return facebookWindow.Title.Trim().Contains("Facebook") ? true : false;
        
        }

        public bool ClickAndVerifyShareTwitter()
        {

            IWebElement elementTwitter = driver.FindElement(By.CssSelector(".page .ct-social-share iframe#twitter-widget-0"));
            IWebDriver iframeDriver = driver.SwitchTo().Frame(elementTwitter);

            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);",
                iframeDriver.FindElement(By.CssSelector(".btn-o .btn")));
            iframeDriver.FindElement(By.CssSelector(".btn-o .btn")).Click();
            IWebDriver twitterWindow = driver.SwitchTo().Window(driver.WindowHandles[1]);
            return twitterWindow.Title.Contains("Twitter") ? true : false;

        }

        public void ClickShareTwitter()
        {
            driver.FindElement(By.CssSelector("#twitter-widget-0 button")).Click();
        }

        public bool ClickandVerifyDownloadAudio()
        {
            driver.FindElement(By.CssSelector(".cs-has-media li a.ico-download")).Click();
            return new WebDriverWait(driver, TimeSpan.FromSeconds(5)).Until(ExpectedConditions.UrlContains(".mp3"));
        }

        public bool ClickandVerifyListenAudio()
        {
            driver.FindElement(By.CssSelector(".cs-has-media li a.ico-audio")).Click();
            IWebDriver audioListenWindow = driver.SwitchTo().Window(driver.WindowHandles[1]);
            return new WebDriverWait(audioListenWindow, TimeSpan.FromSeconds(5)).Until(ExpectedConditions.UrlContains("play=true"));
        }

        public void CloseWindow()
        {
            string a = driver.CurrentWindowHandle;
            driver.SwitchTo().Window(a).Close();
            driver.SwitchTo().Window(driver.WindowHandles[0]);
        }

        



    }
}

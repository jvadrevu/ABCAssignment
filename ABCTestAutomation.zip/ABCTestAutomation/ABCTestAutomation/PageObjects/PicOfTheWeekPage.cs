﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.PageObjects
{
    public class PicOfTheWeekPage : ABCNewsBasePage, IAssertPage
    {
        public PicOfTheWeekPage(IWebDriver driver) : base(driver)
        {

        }

        private IWebElement GetActiveImageFromGallery()
        {
            return driver.FindElement(By.CssSelector(".imageGallery li.active"));
        }

        public bool AssertPage()
        {
            return new WebDriverWait(driver, TimeSpan.FromSeconds(5)).Until(ExpectedConditions.TitleContains("Your best pictures from the week - ABC News (Australian Broadcasting Corporation)"));
        }
        
        public bool IsImageGalleryLoaded()
        {
            return driver.FindElement(By.CssSelector(".imageGallery")).Displayed;
        }

        public void ClickPrev()
        {
            IWebElement leftButton = driver.FindElement(By.CssSelector(".lSAction .lSPrev"));
            String dataDisabled = leftButton.GetAttribute("data-disabled");
            if(dataDisabled == null)
                 driver.FindElement(By.CssSelector(".lSAction .lSPrev")).Click();
        }

        public void ClickNext()
        {
            IWebElement leftButton = driver.FindElement(By.CssSelector(".lSAction .lSNext"));
            String dataDisabled = leftButton.GetAttribute("data-disabled");
            if (dataDisabled == null)
                driver.FindElement(By.CssSelector(".lSAction .lSNext")).Click();
        }
        
        public bool IsImgLoaded()
        {
           return GetActiveImageFromGallery().FindElement(By.TagName("img")).Displayed;
        }

        public bool IsImgCaptionLoaded()
        {
            return GetActiveImageFromGallery().FindElement(By.TagName("p")).GetAttribute("textContent").Length > 0;
        }
        
        public bool IsPicAvailable()
        {
            IWebElement picOfTheWeek = driver.FindElement(By.CssSelector(".imageGallery li.active img"));
            bool picOfTheWeekLoaded = (Boolean)((IJavaScriptExecutor)driver).ExecuteScript("return arguments[0].complete && typeof arguments[0].naturalWidth != undefined && arguments[0].naturalWidth > 0", picOfTheWeek);
            return (!picOfTheWeekLoaded) ? false : true;
         }
    }
}
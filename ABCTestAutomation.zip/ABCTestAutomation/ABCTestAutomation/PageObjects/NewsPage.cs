﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.PageObjects
{
   public class NewsPage : ABCNewsBasePage
    {
        public NewsPage(IWebDriver driver) : base(driver)
        {

        }

        //Scenario 1 : Verify that the page loads successful.
        public bool AssertPage()
        {
            return new WebDriverWait(driver,TimeSpan.FromSeconds(5)).Until(ExpectedConditions.TitleContains("ABC News (Australian Broadcasting Corporation)"));
        }
    }

}

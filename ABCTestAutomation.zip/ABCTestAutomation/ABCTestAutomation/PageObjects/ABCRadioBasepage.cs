﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ABCTestAutomation.PageObjects
{
    public class ABCRadioBasePage
    {
        public IWebDriver driver;
        public ABCRadioBasePage(IWebDriver driver)
        {
            this.driver = driver;
        }
        //Scenario 3 To navigate to Justin page
        public void ClickMenu(string menuText, string submenuText = null)
        {

            List<IWebElement> menuItemsList = driver.FindElements(By.CssSelector(".rn-nav ul li")).ToList();
            foreach (IWebElement menuElement in menuItemsList)
            {
                if (menuElement.Text.ToLower().Trim().Equals(menuText.ToLower().Trim()))
                {
                    menuElement.Click();

                    if (!string.IsNullOrEmpty(submenuText))
                    {
                        List<IWebElement> submenuItemsList = driver.FindElements(By.CssSelector(".rn-nav ul li #rn-programindex li")).ToList();
                        foreach (IWebElement submenuElement in submenuItemsList)
                        {
                            if (submenuElement.Text.ToLower().Trim().Equals(submenuText.ToLower().Trim()))
                            {
                                submenuElement.Click();
                                break;
                            }

                        }
                    }
                    break;
                }
            }
        }

        public void SetSearchText(string srchText)
        {
            driver.FindElement(By.Id("search-simple-input-query")).SendKeys(srchText);
        }

        public void ClickSearch()
        {
            driver.FindElement(By.Id("search-simple-input-submit")).Click();
        }
    }
}

﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.PageObjects
{
  public  class SearchPage : ABCRadioBasePage, IAssertPage
    {
        public SearchPage(IWebDriver driver) : base(driver)
        {

        }

        public bool AssertPage()
        {
            return new WebDriverWait(driver, TimeSpan.FromSeconds(5)).Until(ExpectedConditions.TitleContains("Search - ABC Radio National (Australian Broadcasting Corporation)"));
        }

        public bool IsSeachcontentAvailable()
        {
            return driver.FindElements(By.CssSelector(".article-index")).ToList().Count > 0 ?  true : false;
        }

        public string GetSearchRecordCountMessage()
        {
            return driver.FindElement(By.ClassName("ct-search-header")).Text;
        }
    }
}

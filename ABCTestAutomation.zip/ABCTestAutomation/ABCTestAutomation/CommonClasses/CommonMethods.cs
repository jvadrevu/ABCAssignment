﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestAutomation.CommonClasses
{
   public class CommonMethods
    {
        public IWebDriver driver;
        public CommonMethods(IWebDriver driver)
        {
            this.driver = driver;
        }

        public string getPageTitle()
        {
          return driver.FindElement(By.TagName("title")).Text;
        }
    }
}

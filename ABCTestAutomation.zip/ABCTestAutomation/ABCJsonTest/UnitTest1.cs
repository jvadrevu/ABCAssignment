﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Configuration;
using System.Net;
using Newtonsoft.Json;

namespace ABCJsonTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void JsonTest()
        {
            Dictionary<string, string> expectedKeyParams = new Dictionary<string, string>();
            expectedKeyParams.Add("entity", "Program");
            expectedKeyParams.Add("arid", "ppJj0E8g2R");
            expectedKeyParams.Add("title", "Mornings");
            expectedKeyParams.Add("mini_synopsis", "Mornings presents local news and issues, talking with everyday folk about current issues");
            expectedKeyParams.Add("short_synopsis", "Mornings presents local news and issues, talking with everyday folk about current issues.");
            expectedKeyParams.Add("medium_synopsis", "Mornings presents local news and issues, talking with everyday folk about current issues. Local stories and issues are at the heart of the Mornings program, bringing you fresh local and regional information - including your opportunity to ask direct questions to the ACT Chief Minster each Friday");
            expectedKeyParams.Add("created_utc", "2014-10-09T05:01:49+0000");
            expectedKeyParams.Add("last_updated_utc", "2017-04-28T06:32:56+0000");
            expectedKeyParams.Add("service_airport_code", "");

            string url = ConfigurationManager.AppSettings["dev"];
            var json = new WebClient().DownloadString(url);
            Dictionary<string, string> actualKeyParams = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);

            Assert.IsTrue(expectedKeyParams.Keys.Count.Equals(actualKeyParams.Keys.Count), "Verify that the no of key params in expected and actual json response are same");

            foreach (var param in expectedKeyParams)
            {
                Assert.IsTrue(actualKeyParams.ContainsKey(param.Key), "Verify whether the actual json response contains expected json key ");
                if (param.Value != "")
                {
                    Assert.IsTrue(param.Value.Equals(actualKeyParams[param.Key]), "Verify whether the actual json key value matches with expected key value ");
                }
                else
                {
                    Assert.IsTrue(actualKeyParams[param.Key] == null);
                }
            }

        }

    }
}
